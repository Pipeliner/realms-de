use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process::{Child, Command, ExitStatus};
use std::thread;
use std::time::{Duration, Instant};

use realm_theme::generation::GenerationStore;

struct RunningStub {
    child: Child,
    pid_path: PathBuf,
    args_path: PathBuf,
}

impl Drop for RunningStub {
    fn drop(&mut self) {
        if self.child.try_wait().ok().flatten().is_none() {
            let _ = self.child.kill();
            let _ = self.child.wait();
        }
    }
}

impl RunningStub {
    fn wait_until_stopped(&mut self) -> u32 {
        let deadline = Instant::now() + Duration::from_secs(5);
        loop {
            if let Ok(raw) = fs::read_to_string(&self.pid_path) {
                return raw.trim().parse().unwrap();
            }
            if let Some(status) = self.child.try_wait().unwrap() {
                panic!("fixed consumer exited before exec fixture stopped: {status}");
            }
            assert!(
                Instant::now() < deadline,
                "fixed consumer fixture timed out"
            );
            thread::sleep(Duration::from_millis(10));
        }
    }

    fn resume_and_wait(&mut self, pid: u32) -> ExitStatus {
        let pid = rustix::process::Pid::from_raw(i32::try_from(pid).unwrap()).unwrap();
        rustix::process::kill_process(pid, rustix::process::Signal::CONT).unwrap();
        self.child.wait().unwrap()
    }
}

fn install_stopping_stub(directory: &Path, name: &str) {
    let path = directory.join(name);
    fs::write(
        &path,
        "#!/bin/sh\nif [ \"$1\" = --check-config ]; then exit 0; fi\nprintf '%s\\n' \"$$\" > \"$REALM_TEST_PID\"\nprintf '%s\\n' \"$@\" > \"$REALM_TEST_ARGS\"\nkill -STOP \"$$\"\n",
    )
    .unwrap();
    fs::set_permissions(path, PermissionsExt::from_mode(0o700)).unwrap();
}

fn spawn_consumer(root: &Path, runtime: &Path, stub_dir: &Path, kind: &str) -> RunningStub {
    let pid_path = root.join(format!("{kind}.pid"));
    let args_path = root.join(format!("{kind}.args"));
    let child = Command::new(env!("CARGO_BIN_EXE_realm-wm"))
        .args(["--fixed-consumer", kind])
        .env("XDG_CONFIG_HOME", root)
        .env("XDG_RUNTIME_DIR", runtime)
        .env_remove("HOME")
        .env("PATH", stub_dir)
        .env("REALM_TEST_PID", &pid_path)
        .env("REALM_TEST_ARGS", &args_path)
        .spawn()
        .unwrap();
    RunningStub {
        child,
        pid_path,
        args_path,
    }
}

fn lease_names(root: &Path) -> Vec<String> {
    let mut names = fs::read_dir(root.join("realm/generated/leases"))
        .unwrap()
        .map(|entry| entry.unwrap().file_name().into_string().unwrap())
        .collect::<Vec<_>>();
    names.sort();
    names
}

#[test]
fn fixed_consumers_exec_exact_generation_argv_and_hold_the_ordinary_process_lease() {
    let root = tempfile::tempdir().unwrap();
    let stubs = tempfile::tempdir().unwrap();
    let runtime = tempfile::tempdir().unwrap();
    fs::set_permissions(runtime.path(), PermissionsExt::from_mode(0o700)).unwrap();
    install_stopping_stub(stubs.path(), "foot");
    install_stopping_stub(stubs.path(), "fuzzel");
    realm_theme::apply(root.path()).unwrap();
    realm_session::login_theme::prepare(root.path(), runtime.path(), std::process::id()).unwrap();
    let generation = realm_session::login_theme::load(runtime.path())
        .unwrap()
        .as_str()
        .to_owned();

    for kind in ["terminal", "launcher"] {
        let generation_path = root
            .path()
            .join("realm/generated/generations")
            .join(&generation);
        let expected_args = if kind == "terminal" {
            vec![
                format!(
                    "--config={}",
                    generation_path.join("foot/foot-modern.ini").display()
                ),
                "--log-level=error".to_owned(),
                "--override=key-bindings.spawn-terminal=none".to_owned(),
                "zsh".to_owned(),
            ]
        } else {
            vec![format!(
                "--config={}",
                generation_path.join("fuzzel/fuzzel.ini").display()
            )]
        };
        let mut running = spawn_consumer(root.path(), runtime.path(), stubs.path(), kind);
        let pid = running.wait_until_stopped();
        assert_eq!(pid, running.child.id(), "exec changed the consumer pid");
        assert_eq!(
            fs::read_to_string(&running.args_path)
                .unwrap()
                .lines()
                .collect::<Vec<_>>(),
            expected_args.iter().map(String::as_str).collect::<Vec<_>>()
        );
        let leases = lease_names(root.path());
        assert_eq!(
            leases.len(),
            2,
            "login owner and consumer must each retain one lease"
        );
        assert!(leases.iter().any(|lease| fs::read_to_string(
            root.path().join("realm/generated/leases").join(lease)
        )
        .unwrap()
        .contains(&format!("pid {pid}\n"))));

        let next = realm_theme::apply(root.path()).unwrap().as_str().to_owned();
        assert_ne!(next, generation, "the fixture did not switch current");
        let store = GenerationStore::open(&root.path().join("realm/generated")).unwrap();
        store.garbage_collect().unwrap();
        assert!(
            generation_path.is_dir(),
            "GC removed N while its fixed consumer was still alive"
        );

        assert!(running.resume_and_wait(pid).success());
        let store = GenerationStore::open(&root.path().join("realm/generated")).unwrap();
        assert_eq!(store.garbage_collect().unwrap().reclaimed_leases, 1);
        assert_eq!(
            lease_names(root.path()).len(),
            1,
            "login lease must survive consumer exit"
        );
    }
}

#[test]
fn fixed_consumer_mode_accepts_only_one_known_consumer_argument() {
    let root = tempfile::tempdir().unwrap();
    realm_theme::apply(root.path()).unwrap();
    for args in [
        vec!["--fixed-consumer"],
        vec!["--fixed-consumer", "unknown"],
        vec!["--fixed-consumer", "terminal", "extra"],
    ] {
        let status = Command::new(env!("CARGO_BIN_EXE_realm-wm"))
            .args(args)
            .env("XDG_CONFIG_HOME", root.path())
            .env_remove("HOME")
            .status()
            .unwrap();
        assert!(!status.success());
        assert!(lease_names(root.path()).is_empty());
    }
}

#[test]
fn fixed_consumer_exec_failure_releases_its_process_lease() {
    let root = tempfile::tempdir().unwrap();
    realm_theme::apply(root.path()).unwrap();
    let runtime = tempfile::tempdir().unwrap();
    fs::set_permissions(runtime.path(), PermissionsExt::from_mode(0o700)).unwrap();
    realm_session::login_theme::prepare(root.path(), runtime.path(), std::process::id()).unwrap();
    let empty_path = tempfile::tempdir().unwrap();

    let status = Command::new(env!("CARGO_BIN_EXE_realm-wm"))
        .args(["--fixed-consumer", "terminal"])
        .env("XDG_CONFIG_HOME", root.path())
        .env("XDG_RUNTIME_DIR", runtime.path())
        .env_remove("HOME")
        .env("PATH", empty_path.path())
        .status()
        .unwrap();

    assert!(!status.success());
    assert_eq!(lease_names(root.path()).len(), 1);
}
