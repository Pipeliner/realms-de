#!/bin/sh
# Realm-workspace B2: real Debian/RPM drivers consume only retained authority.
set -eu

root=$(CDPATH='' cd "$(dirname "$0")/../.." && pwd)
kit_builder=$root/packaging/tool-sources/build-native-source-kits.sh
cargo_wrapper=$root/packaging/tool-sources/native-cargo-wrapper.sh
native_tmp=${REALM_NATIVE_TMPDIR:-${TMPDIR:-/tmp}}
failures=0

fail() {
    echo "FAIL: $*" >&2
    failures=$((failures + 1))
}

real_cargo=${REALM_REAL_CARGO:-$(command -v cargo || true)}
real_rustc=${REALM_REAL_RUSTC:-$(command -v rustc || true)}
if [ ! -x "$real_cargo" ] || [ ! -x "$real_rustc" ]; then
    echo "real Cargo or rustc is not executable" >&2
    exit 1
fi
if ! "$real_cargo" --version >/dev/null 2>&1 \
    || ! "$real_rustc" --version >/dev/null 2>&1; then
    echo "real Cargo or rustc cannot execute" >&2
    exit 1
fi
real_rust_bin=$(dirname "$real_rustc")

for command in dh dpkg-deb gzip rpm2archive rpmbuild python3 tar zstd; do
    if ! command -v "$command" >/dev/null 2>&1; then
        echo "required native-build test command is missing: $command" >&2
        exit 1
    fi
done

if ! python3 - "$native_tmp" <<'PY'
import ctypes
import errno
import os
import platform
import sys
import tempfile

syscalls = {
    "aarch64": 276,
    "armv7l": 382,
    "ppc64le": 353,
    "s390x": 347,
    "x86_64": 316,
}
directory = sys.argv[1]
number = syscalls.get(platform.machine())
if number is None:
    raise SystemExit(f"unsupported architecture for renameat2 preflight: {platform.machine()}")
with tempfile.TemporaryDirectory(dir=directory) as probe:
    temporary = os.path.join(probe, "temporary")
    final = os.path.join(probe, "final")
    with open(temporary, "w", encoding="utf-8") as stream:
        stream.write("native-build-preflight")
    libc = ctypes.CDLL(None, use_errno=True)
    result = libc.syscall(number, -100, temporary.encode(), -100, final.encode(), 1)
    if result != 0:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error))
    if os.path.exists(temporary) or open(final, encoding="utf-8").read() != "native-build-preflight":
        raise OSError(errno.EIO, "renameat2 no-replace did not publish the probe file")
    descriptor = os.open(probe, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    unnamed = os.open(probe, os.O_RDWR | os.O_TMPFILE, 0o600)
    try:
        os.write(unnamed, b"native-build-preflight")
        os.fsync(unnamed)
    finally:
        os.close(unnamed)
PY
then
    echo "native-build temporary directory lacks lifecycle filesystem capabilities: $native_tmp" >&2
    exit 1
fi

tmp=$(mktemp -d "$native_tmp/realm-native-builds.XXXXXX")
trap 'rm -rf "$tmp"' EXIT HUP INT TERM

"$kit_builder" "$tmp/production"

run_isolated() {
    if [ "${REALM_NATIVE_NETWORK_ISOLATED:-0}" = 1 ]; then
        "$@"
    elif unshare --user --map-root-user --net true >/dev/null 2>&1; then
        unshare --user --map-root-user --net "$@"
    else
        echo "cannot create the mandatory network namespace" >&2
        exit 1
    fi
}

make_debian_kit() {
    kit=$1
    cp -R "$tmp/production/realm-debian-0.1.0" "$kit"
}

make_rpm_tree() {
    tree=$1
    mkdir -p "$tree/top/SOURCES" "$tree/top/SPECS" \
        "$tree/top/BUILD" "$tree/top/BUILDROOT" "$tree/top/RPMS" "$tree/top/SRPMS"
    cp "$tmp/production/realm-0.1.0.tar.gz" "$tree/top/SOURCES/realm-0.1.0.tar.gz"
    cp "$tmp/production/realm.spec" "$tree/top/SPECS/realm.spec"
}

make_sentinels() {
    directory=$1
    mkdir -p "$directory"
    for command in git curl wget ssh scp; do
        sed "s/@COMMAND@/$command/g" >"$directory/$command" <<'EOF'
#!/bin/sh
printf 'forbidden|command=@COMMAND@|cwd=%s|args=%s\n' "$PWD" "$*" >>"${REALM_SENTINEL_LOG:?}"
exit 97
EOF
        chmod +x "$directory/$command"
    done
    cp "$cargo_wrapper" "$directory/cargo"
    chmod +x "$directory/cargo"
}

make_rustc_selector() {
    directory=$1
    mkdir -p "$directory"
    cat >"$directory/rustc" <<'EOF'
#!/bin/sh
printf 'rustc-selector|cwd=%s|args=%s\n' "$PWD" "$*" >>"${REALM_SENTINEL_LOG:?}"
exit 97
EOF
    chmod +x "$directory/rustc"
}

make_versioned_toolchain_root() {
    root=$1
    cargo_path=$2
    rustc_path=$3
    bin=$root/usr/lib/rust-1.90/bin
    mkdir -p "$bin"
    # Cargo instrumentation is transparent: it immediately execs REALM_REAL_CARGO.
    # The resolver nevertheless sees a complete versioned pair, including in
    # Debhelper's nested make invocation.
    ln -s "$cargo_path" "$bin/cargo"
    ln -s "$rustc_path" "$bin/rustc"
}

run_debian() {
    kit=$1
    log=$2
    source=$kit/debian/realm-workspace/source
    cargo_home=$kit/debian/realm-workspace/.cargo
    cargo_config=$kit/packaging/tool-sources/bundles/realm-workspace/config.toml
    target_dir=$kit/debian/cargo-target
    fixture_state=$kit.fixture-state
    sentinels=$fixture_state/sentinels
    selectors=$fixture_state/selectors
    make_sentinels "$sentinels"
    make_rustc_selector "$selectors"
    versioned_root=$fixture_state/versioned-rust
    make_versioned_toolchain_root "$versioned_root" "$sentinels/cargo" "$real_rustc"
    mkdir -p "$fixture_state/outer-cargo-home"
    run_isolated env \
        PATH="$sentinels:$real_rust_bin:/usr/bin:/bin" \
        RUSTC="$selectors/rustc" \
        RUSTC_WRAPPER="$selectors/rustc" \
        RUSTC_WORKSPACE_WRAPPER="$selectors/rustc" \
        CARGO_BUILD_RUSTC="$selectors/rustc" \
        CARGO_BUILD_RUSTC_WRAPPER="$selectors/rustc" \
        CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER="$selectors/rustc" \
        CARGO_HOME="$fixture_state/outer-cargo-home" \
        REALM_EXPECTED_SOURCE="$source" \
        REALM_EXPECTED_CARGO_HOME="$cargo_home" \
        REALM_EXPECTED_CARGO_CONFIG="$cargo_config" \
        REALM_EXPECTED_TARGET_DIR="$target_dir" \
        REALM_SENTINEL_LOG="$log" \
        REALM_REAL_CARGO="$real_cargo" \
        REALM_REAL_RUSTC="$real_rustc" \
        REALM_RUST_VERSIONED_ROOT="$versioned_root" \
        RUSTC="$real_rustc" \
        RUSTC_WRAPPER= \
        RUSTC_WORKSPACE_WRAPPER= \
        CARGO_BUILD_RUSTC="$real_rustc" \
        CARGO_BUILD_RUSTC_WRAPPER= \
        CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER= \
        CARGO_INCREMENTAL=0 \
        CARGO_PROFILE_RELEASE_DEBUG=0 \
        make -C "$kit" -f debian/rules binary
}

assert_current_package_guide() {
    guide_name=$1
    guide_root=$2
    guide_output=$3
    guide_path=$(find "$guide_root/usr/share/doc" -type f \
        \( -name 'INSTALL.md' -o -name 'INSTALL.md.gz' \) -print -quit)
    if [ -z "$guide_path" ]; then
        fail "$guide_name package omitted its installed build guide"
        return
    fi
    case $guide_path in
        *.gz) gzip -cd "$guide_path" >"$guide_output" ;;
        *) cp "$guide_path" "$guide_output" ;;
    esac
    if grep -F 'ln -s packaging/debian' "$guide_output" >/dev/null \
        || grep -F 'git archive' "$guide_output" >/dev/null; then
        fail "$guide_name package installed a guide with a forbidden build workflow"
    fi
    if ! grep -F 'packaging/tool-sources/build-native-source-kits.sh' \
        "$guide_output" >/dev/null; then
        fail "$guide_name package installed a guide without the retained-kit producer"
    fi
    case $guide_name in
        Debian)
            required_install='sudo apt install devscripts debhelper rustc-1.89 cargo-1.89 pkg-config python3 zstd fonts-dejavu-core'
            ;;
        RPM)
            required_install='sudo dnf install rpm-build rust cargo systemd-rpm-macros make python3 zstd dejavu-sans-fonts dejavu-sans-mono-fonts'
            ;;
    esac
    if ! grep -F -x "$required_install" "$guide_output" >/dev/null; then
        fail "$guide_name package installed a guide without its clean-host build prerequisites"
    fi
}

run_rpm() {
    tree=$1
    log=$2
    top=$tree/top
    source=$top/BUILD/realm-0.1.0/.realm-workspace/source
    cargo_home=$top/BUILD/realm-0.1.0/.realm-workspace/.cargo
    cargo_config=$top/BUILD/realm-0.1.0/packaging/tool-sources/bundles/realm-workspace/config.toml
    target_dir=$top/BUILD/realm-0.1.0/.cargo-target
    sentinels=$tree/sentinels
    selectors=$tree/selectors
    make_sentinels "$sentinels"
    make_rustc_selector "$selectors"
    mkdir -p "$tree/home" "$tree/outer-cargo-home"
    run_isolated env \
        HOME="$tree/home" \
        PATH="$sentinels:$real_rust_bin:/usr/bin:/bin" \
        RUSTC="$selectors/rustc" \
        RUSTC_WRAPPER="$selectors/rustc" \
        RUSTC_WORKSPACE_WRAPPER="$selectors/rustc" \
        CARGO_BUILD_RUSTC="$selectors/rustc" \
        CARGO_BUILD_RUSTC_WRAPPER="$selectors/rustc" \
        CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER="$selectors/rustc" \
        CARGO_HOME="$tree/outer-cargo-home" \
        REALM_EXPECTED_SOURCE="$source" \
        REALM_EXPECTED_CARGO_HOME="$cargo_home" \
        REALM_EXPECTED_CARGO_CONFIG="$cargo_config" \
        REALM_EXPECTED_TARGET_DIR="$target_dir" \
        REALM_SENTINEL_LOG="$log" \
        REALM_REAL_CARGO="$real_cargo" \
        REALM_REAL_RUSTC="$real_rustc" \
        RUSTC="$real_rustc" \
        RUSTC_WRAPPER= \
        RUSTC_WORKSPACE_WRAPPER= \
        CARGO_BUILD_RUSTC="$real_rustc" \
        CARGO_BUILD_RUSTC_WRAPPER= \
        CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER= \
        CARGO_INCREMENTAL=0 \
        CARGO_PROFILE_RELEASE_DEBUG=0 \
        rpmbuild -bb --nodeps \
            --define "_topdir $top" \
            --define "rust_arches $(uname -m)" \
            --define "_userunitdir /usr/lib/systemd/user" \
            "$top/SPECS/realm.spec"
}

rejects_before_cargo() {
    name=$1
    runner=$2
    fixture=$3
    log=$4
    output=$5
    : >"$log"
    if "$runner" "$fixture" "$log" >"$output" 2>&1; then
        fail "$name accepted a same-name source archive with a different digest"
    elif ! grep -F 'source SHA-256 mismatch' "$output" >/dev/null; then
        fail "$name rejected the substitution for the wrong reason"
        sed -n '1,120p' "$output" >&2
    fi
    if grep '^cargo|' "$log" >/dev/null; then
        fail "$name invoked Cargo before source-digest refusal"
    fi
}

accepts_offline_cargo() {
    name=$1
    runner=$2
    fixture=$3
    log=$4
    output=$5
    package_root=
    : >"$log"
    if "$runner" "$fixture" "$log" >"$output" 2>&1; then
        runner_status=0
    else
        runner_status=$?
        fail "$name valid source kit did not complete its native build path"
        printf '%s native-driver exit status: %s\n' "$name" "$runner_status" >&2
        sed -n '1,160p' "$output" >&2
        printf '%s native-driver output tail:\n' "$name" >&2
        tail -n 80 "$output" >&2
        printf '%s native-driver artifact candidates:\n' "$name" >&2
        find "$fixture" -type f \( -name '*.deb' -o -name '*.rpm' \) -print >&2
    fi
    if grep '^forbidden|' "$log" >/dev/null; then
        fail "$name invoked Git or a network command"
    fi
    if grep '^rustc-selector|' "$log" >/dev/null; then
        fail "$name honored an inherited rustc selector"
    fi
    if grep '^cargo-home-not-retained-config|' "$log" >/dev/null; then
        fail "$name did not use an otherwise-empty Cargo home containing the retained source configuration"
    fi
    cargo_count=$(grep -c '^cargo|' "$log" || true)
    if [ "$cargo_count" -ne 4 ]; then
        fail "$name made $cargo_count Cargo invocations instead of three builds and one test"
    fi
    build_count=$(grep -c '|args=build ' "$log" || true)
    test_count=$(grep -c '|args=test ' "$log" || true)
    if [ "$build_count" -ne 3 ] || [ "$test_count" -ne 1 ]; then
        fail "$name did not make exactly three Cargo builds and one Cargo test invocation"
    fi
    build_invocation=$(grep '|args=build .*--workspace' "$log" | head -n 1 || true)
    case $build_invocation in
        *"|args=build --release --frozen --offline --locked --workspace|cflags="*) ;;
        *) fail "$name did not run the exact complete staged workspace build" ;;
    esac
    yazi_invocation=$(grep '|args=build .*--package yazi-fm' "$log" | head -n 1 || true)
    case $yazi_invocation in
        *"|args=build --release --frozen --offline --locked --package yazi-fm --package yazi-cli|cflags="*) ;;
        *) fail "$name did not run the exact selected Yazi build" ;;
    esac
    case $yazi_invocation in
        *"|cflags="*" -std=gnu17"*) ;;
        *) fail "$name did not select GNU C17 for the retained Yazi C dependency" ;;
    esac
    starship_invocation=$(grep '|args=build .*--bin starship' "$log" | head -n 1 || true)
    case $starship_invocation in
        *"|args=build --release --frozen --offline --locked --bin starship|cflags="*) ;;
        *) fail "$name did not run the exact selected Starship build" ;;
    esac
    case "$build_invocation $starship_invocation" in
        *" -std=gnu17"*) fail "$name leaked the Yazi C standard selection into another build" ;;
        *) ;;
    esac
    test_invocation=$(grep '|args=test ' "$log" | head -n 1 || true)
    case $test_invocation in
        *"|args=test --release --frozen --offline --locked --workspace --exclude realm-agent-sdd|cflags="*) ;;
        *) fail "$name did not run the exact package-relevant workspace test selection" ;;
    esac
    for bin in realmctl realm-wm realm-bar yazi ya starship; do
        if ! grep -F -x "cargo-output|binary=$bin|executable=yes" "$log" >/dev/null; then
            fail "$name Cargo build did not produce $bin"
        fi
    done
    case $name in
        Debian)
            deb_artifact=$(find "$REALM_EXPECTED_PACKAGE_ROOT" -maxdepth 1 \
                -type f -name 'realm_*_*.deb' -print -quit)
            if [ -z "$deb_artifact" ]; then
                fail "$name native driver did not emit a package artifact"
            else
                mkdir -p "$output.deb-root"
                dpkg-deb -x "$deb_artifact" "$output.deb-root"
                for bin in realmctl realm-wm realm-bar; do
                    if [ ! -x "$output.deb-root/usr/bin/$bin" ]; then
                        fail "$name package did not contain the staged workspace $bin"
                    fi
                done
                package_root=$output.deb-root
                assert_current_package_guide "$name" "$output.deb-root" \
                    "$output.package-guide"
            fi
            ;;
        RPM)
            rpm_artifact=$(find "$REALM_EXPECTED_PACKAGE_ROOT" -type f \
                -name 'realm-*.rpm' -print -quit)
            if [ -z "$rpm_artifact" ]; then
                fail "$name native driver did not emit a package artifact"
            else
                for bin in realmctl realm-wm realm-bar; do
                    if ! rpm -qpl "$rpm_artifact" | grep -Fx "/usr/bin/$bin" >/dev/null; then
                        fail "$name package did not contain the staged workspace $bin"
                    fi
                done
                mkdir -p "$output.rpm-archive" "$output.rpm-root"
                rpm_tar=$output.rpm-archive/package.tgz
                if ! rpm2archive "$rpm_artifact" >"$rpm_tar"; then
                    fail "$name package could not be converted for guide inspection"
                else
                    tar -C "$output.rpm-root" -xzf "$rpm_tar"
                    package_root=$output.rpm-root
                    assert_current_package_guide "$name" "$output.rpm-root" \
                        "$output.package-guide"
                fi
            fi
            ;;
    esac
    if [ -n "${package_root:-}" ]; then
        for bin in yazi ya starship; do
            private=$package_root/usr/lib/realm/bin/$bin
            if [ ! -x "$private" ]; then
                fail "$name package omitted private $bin"
            fi
            if [ -e "$package_root/usr/bin/$bin" ] || [ -L "$package_root/usr/bin/$bin" ]; then
                fail "$name package took ownership of /usr/bin/$bin"
            fi
            resolved=$(PATH="$package_root/usr/lib/realm/bin:/usr/bin:/bin" command -v "$bin" || true)
            if [ "$resolved" != "$private" ]; then
                fail "$name Realm session PATH did not resolve private $bin"
            fi
        done
        yazi_version=$("$package_root/usr/lib/realm/bin/yazi" --version 2>&1 || true)
        ya_version=$("$package_root/usr/lib/realm/bin/ya" --version 2>&1 || true)
        starship_version=$("$package_root/usr/lib/realm/bin/starship" --version 2>&1 || true)
        if [ "$yazi_version" != \
            'Yazi 25.4.8 (99ea3b74c4260a724b43af812df0f68ef59395b7 2025-04-08)' ]; then
            fail "$name package has unexpected Yazi version metadata: $yazi_version"
        fi
        if [ "$ya_version" != \
            'Ya 25.4.8 (99ea3b74c4260a724b43af812df0f68ef59395b7 2025-04-08)' ]; then
            fail "$name package has unexpected ya version metadata: $ya_version"
        fi
        starship_version_first=$(printf '%s\n' "$starship_version" | sed -n '1p')
        if [ "$starship_version_first" != 'starship 1.23.0' ]; then
            fail "$name package has unexpected Starship version: $starship_version"
        fi
        case $name in
            Debian)
                debian_yazi_version=$yazi_version
                debian_ya_version=$ya_version
                ;;
            RPM)
                rpm_yazi_version=$yazi_version
                rpm_ya_version=$ya_version
                ;;
        esac
    fi
    if ! grep -F 'test result: ok.' "$output" >/dev/null; then
        fail "$name Cargo test did not execute the staged workspace tests"
    fi
    result_count=$(grep -c '^cargo-result|status=0$' "$log" || true)
    if [ "$result_count" -ne 4 ]; then
        fail "$name did not complete all four real Cargo invocations successfully"
    fi
    grep '^cargo|' "$log" >"$output.cargo"
    while IFS= read -r invocation; do
        case $invocation in
            *"|cwd=${REALM_EXPECTED_SOURCE}|home=${REALM_EXPECTED_CARGO_HOME}|"* \
            | *"|cwd=${REALM_EXPECTED_YAZI_SOURCE}|home=${REALM_EXPECTED_YAZI_CARGO_HOME}|"* \
            | *"|cwd=${REALM_EXPECTED_STARSHIP_SOURCE}|home=${REALM_EXPECTED_STARSHIP_CARGO_HOME}|"*) ;;
            *) fail "$name invoked Cargo outside a selected retained stage" ;;
        esac
        for flag in --frozen --offline --locked; do
            case " $invocation " in
                *" $flag "*) ;;
                *) fail "$name Cargo invocation omitted $flag" ;;
            esac
        done
    done <"$output.cargo"
}

rejects_injected_fetch() {
    name=$1
    runner=$2
    fixture=$3
    log=$4
    output=$5
    : >"$log"
    if "$runner" "$fixture" "$log" >"$output" 2>&1; then
        fail "$name executed an injected fetch without failing"
    fi
    if ! grep '^forbidden|command=git|' "$log" >/dev/null; then
        fail "$name injected fetch did not reach the network-command sentinel"
    fi
    if grep '^cargo|' "$log" >/dev/null; then
        fail "$name continued to Cargo after the injected fetch failed"
    fi
}

make_debian_kit "$tmp/debian-invalid"
printf 'different retained bytes\n' >> \
    "$tmp/debian-invalid/packaging/tool-sources/bundles/realm-workspace/source.tar.gz"
rejects_before_cargo Debian run_debian "$tmp/debian-invalid" \
    "$tmp/debian-invalid.log" "$tmp/debian-invalid.out"

make_debian_kit "$tmp/debian-valid"
REALM_EXPECTED_SOURCE="$tmp/debian-valid/debian/realm-workspace/source"
REALM_EXPECTED_CARGO_HOME="$tmp/debian-valid/debian/realm-workspace/.cargo"
REALM_EXPECTED_CARGO_CONFIG="$tmp/debian-valid/packaging/tool-sources/bundles/realm-workspace/config.toml"
REALM_EXPECTED_TARGET_DIR="$tmp/debian-valid/debian/cargo-target"
REALM_EXPECTED_YAZI_SOURCE="$tmp/debian-valid/debian/yazi-25.4.8/source"
REALM_EXPECTED_YAZI_CARGO_HOME="$tmp/debian-valid/debian/yazi-25.4.8/.cargo"
REALM_EXPECTED_STARSHIP_SOURCE="$tmp/debian-valid/debian/starship-1.23.0/source"
REALM_EXPECTED_STARSHIP_CARGO_HOME="$tmp/debian-valid/debian/starship-1.23.0/.cargo"
REALM_EXPECTED_PACKAGE_ROOT="$tmp"
export REALM_EXPECTED_SOURCE REALM_EXPECTED_CARGO_HOME REALM_EXPECTED_CARGO_CONFIG REALM_EXPECTED_TARGET_DIR \
    REALM_EXPECTED_YAZI_SOURCE REALM_EXPECTED_YAZI_CARGO_HOME \
    REALM_EXPECTED_STARSHIP_SOURCE REALM_EXPECTED_STARSHIP_CARGO_HOME \
    REALM_EXPECTED_PACKAGE_ROOT
accepts_offline_cargo Debian run_debian "$tmp/debian-valid" \
    "$tmp/debian-valid.log" "$tmp/debian-valid.out"

make_debian_kit "$tmp/debian-fetch"
sed -i '/^override_dh_auto_build:/a\
\tgit fetch https://example.invalid/realm' "$tmp/debian-fetch/debian/rules"
rejects_injected_fetch Debian run_debian "$tmp/debian-fetch" \
    "$tmp/debian-fetch.log" "$tmp/debian-fetch.out"

make_rpm_tree "$tmp/rpm-invalid"
mkdir -p "$tmp/rpm-invalid/substitution"
tar -C "$tmp/rpm-invalid/substitution" -xzf \
    "$tmp/rpm-invalid/top/SOURCES/realm-0.1.0.tar.gz"
printf 'different retained bytes\n' >> \
    "$tmp/rpm-invalid/substitution/realm-0.1.0/packaging/tool-sources/bundles/realm-workspace/source.tar.gz"
tar -C "$tmp/rpm-invalid/substitution" -czf \
    "$tmp/rpm-invalid/top/SOURCES/realm-0.1.0.tar.gz" realm-0.1.0
rejects_before_cargo RPM run_rpm "$tmp/rpm-invalid" \
    "$tmp/rpm-invalid.log" "$tmp/rpm-invalid.out"

make_rpm_tree "$tmp/rpm-valid"
REALM_EXPECTED_SOURCE="$tmp/rpm-valid/top/BUILD/realm-0.1.0/.realm-workspace/source"
REALM_EXPECTED_CARGO_HOME="$tmp/rpm-valid/top/BUILD/realm-0.1.0/.realm-workspace/.cargo"
REALM_EXPECTED_CARGO_CONFIG="$tmp/rpm-valid/top/BUILD/realm-0.1.0/packaging/tool-sources/bundles/realm-workspace/config.toml"
REALM_EXPECTED_TARGET_DIR="$tmp/rpm-valid/top/BUILD/realm-0.1.0/.cargo-target"
REALM_EXPECTED_YAZI_SOURCE="$tmp/rpm-valid/top/BUILD/realm-0.1.0/.yazi-25.4.8/source"
REALM_EXPECTED_YAZI_CARGO_HOME="$tmp/rpm-valid/top/BUILD/realm-0.1.0/.yazi-25.4.8/.cargo"
REALM_EXPECTED_STARSHIP_SOURCE="$tmp/rpm-valid/top/BUILD/realm-0.1.0/.starship-1.23.0/source"
REALM_EXPECTED_STARSHIP_CARGO_HOME="$tmp/rpm-valid/top/BUILD/realm-0.1.0/.starship-1.23.0/.cargo"
REALM_EXPECTED_PACKAGE_ROOT="$tmp/rpm-valid/top/RPMS"
export REALM_EXPECTED_SOURCE REALM_EXPECTED_CARGO_HOME REALM_EXPECTED_CARGO_CONFIG REALM_EXPECTED_TARGET_DIR \
    REALM_EXPECTED_YAZI_SOURCE REALM_EXPECTED_YAZI_CARGO_HOME \
    REALM_EXPECTED_STARSHIP_SOURCE REALM_EXPECTED_STARSHIP_CARGO_HOME \
    REALM_EXPECTED_PACKAGE_ROOT
accepts_offline_cargo RPM run_rpm "$tmp/rpm-valid" \
    "$tmp/rpm-valid.log" "$tmp/rpm-valid.out"

if [ -n "${debian_yazi_version:-}" ] && [ -n "${rpm_yazi_version:-}" ] \
    && { [ "$debian_yazi_version" != "$rpm_yazi_version" ] \
        || [ "$debian_ya_version" != "$rpm_ya_version" ]; }; then
    fail "Yazi retained metadata differs across isolated native build directories"
fi

make_rpm_tree "$tmp/rpm-fetch"
sed -i '/^%build$/a git fetch https://example.invalid/realm' \
    "$tmp/rpm-fetch/top/SPECS/realm.spec"
rejects_injected_fetch RPM run_rpm "$tmp/rpm-fetch" \
    "$tmp/rpm-fetch.log" "$tmp/rpm-fetch.out"

if [ "$failures" -ne 0 ]; then
    exit 1
fi
