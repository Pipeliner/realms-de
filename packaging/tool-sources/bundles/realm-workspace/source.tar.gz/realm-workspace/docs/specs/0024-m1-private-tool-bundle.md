# SPEC 0024 — M1 private Yazi and Starship tool bundle

- **Status:** Accepted (2026-08-31; amended 2026-09-13)
- **Milestone:** M1
- **Issue:** [#134](https://github.com/Pipeliner/realms-de/issues/134)
- **Refines:** [SPEC 0023](0023-m1-tool-source-intake.md)
- **Decisions:** [ADR 0007](../adr/0007-reuse-yazi-btop-starship.md),
  [ADR 0010](../adr/0010-packaged-realm-sdd-git-runtime.md)
- **Evidence:** [M1 provenance research](../research/2026-08-30-m1-yazi-starship-provenance.md)

## Purpose

Make the SPEC 0023 A2 source-build route concrete for the native M1 packages.
The route supplies Realm-owned Yazi, `ya`, and Starship executables without
network access at package-build time, without taking ownership of distribution
executables, and without publishing any Realm infrastructure.

## Selected compatibility baseline

The first native source-bundle implementation selects these versions and the
existing native Rust floor:

| Tool | Selected version | Compiler baseline | Reason |
|---|---:|---:|---|
| Starship | `1.23.0` | Rust `1.85` | Its tagged manifest declares that floor and the current Realm Starship template was checked against that release. |
| Yazi / `ya` | `25.4.8` | Rust `1.85` | A locked Cargo check completed at that floor, subject to the configuration migration below. |

The currently retained `v1.26.0` and `v26.8.15` archives remain **intake
evidence**, not the selected native package route. Selecting these older
versions requires a reviewed SPEC 0023 intake update that adds their complete
offline closures and provenance records before a package build may consume
them. This specification neither deletes the current records nor treats a
top-level archive as an offline build input.

## Offline bundle contract

For each selected tool, the retained build input SHALL contain, and the
machine-readable intake record SHALL bind by digest:

1. the upstream tagged source archive and its provenance/notice record;
2. the exact `Cargo.lock` used for the build;
3. the complete `cargo vendor` dependency tree generated from that lockfile,
   retained either as regular Git-tracked files or as a deterministic,
   Git-tracked `.tar.zst` archive of that tree;
4. a Cargo source-replacement configuration which addresses every resolved
   Cargo source through retained input (registry, Git, and any applicable path
   source); and
5. a dependency license and notice report identifying every dependency in the
   resolved closure and the source used for its licensing information.

An archived vendor tree SHALL record its compression algorithm, archive digest,
and deterministic tar metadata (sorted names, epoch mtime, numeric owner/group).
The package build SHALL unpack it into an empty bundle-local directory before
Cargo runs; the linkage test SHALL reject a digest mismatch, path escape,
symlink, missing Cargo checksum, or unpacked tree differing from the archived
tree. Compression changes storage representation only: it must not weaken the
complete-closure, source-replacement, or offline-build requirements.

This rule applies equally to **every Cargo invocation performed by the native
package recipes**, including the Realm workspace build and test commands already
in `debian/rules` and `packaging/fedora/realm.spec`. The native source release
SHALL therefore retain a separately identified Realm-workspace `Cargo.lock`,
vendor tree, source-replacement configuration, and dependency license/notice
report, or the recipe SHALL not invoke Cargo for that workspace. It is not
permitted to prove only the bundled tools offline while allowing the package's
own Cargo commands to rely on a pre-populated cache or live registry.

### Realm workspace source authority

The Realm workspace closure SHALL bind to the immutable package source archive
at `packaging/tool-sources/bundles/realm-workspace/source.tar.gz`. That archive
is the source authority and SHALL be the exact archive unpacked for Realm's
Cargo build by both native package paths; no second source copy or build-time,
unbound `git archive` is permitted. A controlled intake MAY create this one
canonical archive from the record-bound repository commit, but it SHALL retain
the resulting bytes and digest as this source authority outside, and before,
either native package path. Debian/RPM preparation and build phases SHALL NOT
invoke `git`, `git archive`, archive creation, or any fetch operation, even if
the resulting bytes would match the recorded digest. Its tracked
`packaging/tool-sources/bundles/realm-workspace/bundle.toml` record SHALL bind
the archive SHA-256 to the repository commit, commit timestamp, and
provenance/notice record used at intake. The linkage fixture SHALL unpack the
source authority, verify the record's archive digest, and require its root
`Cargo.lock` to match the separately retained, digest-bound Realm-workspace
lockfile byte-for-byte.

The controlled intake SHALL exclude `packaging/tool-sources/bundles/` from the
source archive. Those independent retained authorities are inputs to outer
packaging orchestration, not Realm-workspace Cargo source or build/test inputs;
embedding them would recursively duplicate source and dependency closures. The
linkage validator SHALL reject a workspace source authority containing that
directory, and the provenance record SHALL name the exclusion. Any tracked
workspace source or Cargo build/test input changed after the recorded source
commit SHALL refresh the canonical archive from a new committed snapshot before
native package CI can satisfy this contract; passing tests against the moving
checkout do not make a stale retained archive current.

### CI-only Realm workspace rebinding

Producing or rebinding the Realm workspace source authority is packaging and
SHALL run only in the repository's CI. The rebind workflow accepts one exact,
full repository commit ID; checks out that object with complete history; and
creates the archive only from that immutable Git object with the exclusion
above. A branch name, tag, working-tree byte, local archive, or caller-supplied
provenance field is not an admissible source input.

The workflow SHALL refuse a commit whose `Cargo.lock` differs from the retained
Realm-workspace lockfile. Such a change requires a separate controlled
dependency-closure refresh; this path does not vendor dependencies. For an
unchanged lockfile, CI stages the existing digest-bound closure in runner-local
temporary storage, generates `source.tar.gz`, updates only the bound commit,
commit timestamp, source digest, and provenance digest fields, and runs the
normal bundle-linkage validator over the complete candidate bundle.

Successful CI publishes an artifact containing exactly the candidate
`source.tar.gz`, `bundle.toml`, and `provenance.md`. The workflow has read-only
repository permission and SHALL NOT commit or push the result. A maintainer may
place those exact three CI-produced files in the source change; the ordinary
freshness and linkage checks remain authoritative before merge. An uploaded
candidate alone is not package-build, install, or runtime evidence.

The Realm-workspace source-replacement configuration is a separately retained
build input: native recipes SHALL stage it at the unpacked source root before
Cargo runs. The linkage fixture SHALL verify that configuration, the retained
vendor tree, every resolved dependency, and the dependency license report as
for selected tool bundles. Before each **Realm-workspace** Cargo invocation, the
Debian source package path and Fedora `%prep` path SHALL verify the same
retained archive digest and build only its unpacked source tree. The native
offline-build fixture SHALL substitute a same-name source archive with a
different digest in each path and require refusal before Cargo runs. A moving
checkout or unspecified local RPM `Source0` is not an immutable source
authority and SHALL NOT satisfy this contract.

The canonical source authority intentionally contains no Git worktree metadata.
Both native paths SHALL build the complete staged workspace, but their native
test invocation SHALL run all package-relevant staged workspace members and
exclude only the non-packaged `realm-agent-sdd` member: that member's 47 gate
fixtures validate live Git worktree state and remain mandatory in its existing
source-worktree test lane. Native package preparation SHALL NOT synthesize a
Git repository or weaken the no-Git rule merely to run those worktree fixtures.

The outer Debian and RPM source kits SHALL remain packaging inputs rather than
hidden workspaces at every nesting depth. Outside the canonical retained
`packaging/tool-sources/bundles/realm-workspace/source.tar.gz`, a kit SHALL NOT
contain a `Cargo.toml`, `crates/` or `.cargo/` workspace directory, or another
`source.tar.gz`; the separately retained Realm `Cargo.lock` is permitted only at
its one canonical bundle path. This recursive rule applies inside otherwise
allowed packaging-metadata directories as well as at kit top level.

The installed native-package build guide SHALL come from tracked outer
packaging metadata, not from the identity-bound archive's historical
`docs/INSTALL.md`. The emitted Debian and RPM packages SHALL document
the CI-only package build and verification workflow, without local source-kit
producer commands or packaging-toolchain installation instructions, and SHALL
NOT retain the superseded checkout
`ln -s packaging/debian` or moving `git archive ... HEAD` workflows. Updating
package guidance SHALL NOT mutate or regenerate the canonical source authority.
The CI clean-host prerequisite commands SHALL include the direct native recipe
requirements: Debian `pkg-config` and Fedora `make`. Because the package-native
test phase exercises SPEC 0004's raster/text-cache tests, both package recipes
and their CI prerequisite installs SHALL also supply a real DejaVu fallback
font: Debian/Ubuntu uses `fonts-dejavu-core`, while Fedora uses
`dejavu-sans-fonts` and `dejavu-sans-mono-fonts`. The build must not inherit
this test input accidentally from the CI host's font database.

The Debian and Fedora package paths SHALL unpack only these retained inputs and
build using `cargo --frozen --offline --locked`. They MAY consume declared,
target-provided C toolchain/system dependencies, but SHALL NOT acquire an
upstream source, registry package, Git dependency, or release artifact over the
network. The retained source-replacement configuration SHALL remain visible to
Cargo subprocesses launched by package-relevant tests, including generated
trybuild projects outside the staged source tree: native recipes SHALL expose
the staged `.cargo` directory as inherited `CARGO_HOME`, not rely only on
top-level ancestor probing. Compile-fail checks in that package test path SHALL
prove the intended API boundary from the compiler error code and inaccessible
symbol, without requiring diagnostic prose or note layout to be identical
across supported Rust versions. A test fixture SHALL run the actual
`debian/rules` build path and the Fedora RPM build phase with networking
disabled and empty Cargo registry/Git caches, reject a
closure/configuration/lockfile mismatch, and fail when an adversarial
injected-fetch attempt is present in either recipe.

The fixture's disposable build tree SHALL be on a Linux filesystem that
supports `O_TMPFILE` with file `fsync`, atomic `renameat2` publication/exchange,
and directory `fsync`, as required by the retained lifecycle tests. CI SHALL
select that tree explicitly and preflight those operations before invoking
either native package driver; it SHALL NOT skip or weaken the lifecycle tests
when the selected filesystem lacks any capability.

The fixture SHALL invoke its supplied real Cargo and rustc executables, not a
stand-in. It SHALL bind Cargo to that supplied rustc and clear inherited
compiler-wrapper selection. Transparent instrumentation may record a Cargo
invocation only when it execs the supplied real Cargo unchanged. When CI
elevates that fixture, it SHALL first stage a complete Rust toolchain in a
directory readable, traversable, and executable by the elevated process, and
preflight-execute that staged Cargo and rustc. Staging may copy the real
toolchain solely to make it accessible; it SHALL NOT replace either executable
with a shim. The CI step that invokes the network-isolated native fixture SHALL
have a bounded job-step timeout and SHALL fail closed when the fixture exceeds
it; an indefinitely hung isolation check is not verification evidence.

The Debian recipe's production resolver SHALL continue to select its complete
versioned Cargo/rustc pair below `/usr/lib/rust-1.[89][0-9]/bin`.  The native
offline fixture MAY set an explicit resolver-root input that contains the same
versioned layout.  Rules SHALL combine that root with the resolver's logical
selected path before invoking Cargo or rustc, so the fixture executes its
staged supplied pair rather than falling back to inherited `PATH`.  The fixture
root shall provide the supplied real rustc and either the supplied real Cargo
or transparent Cargo instrumentation which immediately execs that supplied
Cargo unchanged.  That input exists only to make the real nested Debhelper
invocation reproducible in an isolated fixture; it SHALL be consumed by the
resolver itself, not used to override its selected binary directory or bypass
the completeness check.

The Yazi build SHALL set deterministic source-date and VCS metadata. The intake
record SHALL bind the selected tag to its upstream commit SHA and commit
timestamp; the package recipe SHALL set the exact version/metadata inputs
accepted by the selected Yazi `vergen` build from those retained values. It
SHALL not accept `vergen`'s fallback metadata as release evidence or assume that
`SOURCE_DATE_EPOCH` alone controls it. The reproducibility fixture SHALL build
in two different directories/times and either compare the normalized declared
artifacts or explicitly record and justify every remaining non-identical field.

## Executable ownership and session scope

Native packages SHALL install only these Realm-owned executables:

```text
/usr/lib/realm/bin/yazi
/usr/lib/realm/bin/ya
/usr/lib/realm/bin/starship
```

They SHALL NOT install or replace `/usr/bin/yazi`, `/usr/bin/ya`, or
`/usr/bin/starship`. Distribution-provided tools remain independently owned and
may coexist.

For the direct-launch path (without a systemd user manager),
`packaging/session/realm-session` SHALL prepend `/usr/lib/realm/bin` to the Realm
session process environment and its descendants. For the normal systemd-user
path, the Realm-owned service units SHALL receive an explicit private PATH by a
Realm-owned unit-level environment mechanism; `realm-wm`, `realm-bar`, and the
applications they launch therefore inherit it without changing the user
manager's global environment. Neither route SHALL add the private path to
`SESSION_ENV_VARS`, `systemctl --user import-environment`, or
`dbus-update-activation-environment`. `REALM_IMPORT_PATH` retains its existing,
explicit opt-in semantics, but its imported caller PATH SHALL be captured before
the private prefix and exclude `/usr/lib/realm/bin`. It is not the mechanism
which makes the private tools available. Tests SHALL prove private-tool lookup
and PATH isolation for both direct and systemd-user launch paths, including the
`REALM_IMPORT_PATH=1` case.

## Yazi v25.4 configuration migration

The current Realm Yazi template targets a different schema and is not valid
configuration evidence for Yazi `25.4.8`. Its migration is part of selecting
that version, rather than a later cosmetic change.

The rendered template SHALL use Yazi v25.4's names as follows:

| Existing Realm field | v25.4 rendered field | Mapping |
|---|---|---|
| `[mgr]` | `[manager]` | Rename the section. |
| `status.mode_normal` | `mode.normal_main`, `mode.normal_alt` | Copy the existing style to both normal variants. |
| `status.mode_select` | `mode.select_main`, `mode.select_alt` | Copy the existing style to both selection variants. |
| `status.mode_unset` | `mode.unset_main`, `mode.unset_alt` | Copy the existing style to both unset variants. |
| `status.permissions_t` | `status.perm_type` | Rename. |
| `status.permissions_r` | `status.perm_read` | Rename. |
| `status.permissions_w` | `status.perm_write` | Rename. |
| `status.permissions_x` | `status.perm_exec` | Rename. |
| `status.permissions_s` | omitted | The selected schema has no corresponding field; omission is intentional. |
| absent field | `status.perm_sep` | Render a separator style using the former `permissions_s` palette role. |

No unsupported renamed field may remain in a rendered v25.4 configuration. A
Hermetic test SHALL render the Realm template at
`YAZI_CONFIG_HOME/theme.toml` and run the selected retained Yazi build in a
controlled terminal-capable environment so its real configuration-loading path
is exercised. A version-pinned strict schema guard SHALL reject the legacy
section and field names before that runtime step: a permissive TOML/Serde parser
is not evidence that an obsolete field had the intended effect. The fixture
shall assert that the canonical fields are consumed, not merely that the TOML
parses.

The Starship validation SHALL render `configs/templates/starship.toml` and run
the selected private `starship prompt` with `STARSHIP_CONFIG`, fixed HOME/cwd,
terminal settings, shell/keymap, status, and command-duration inputs. It SHALL
assert no configuration diagnostic on stderr and a known rendered feature from
the Realm template, rather than only a nonempty default prompt.

## Acceptance criteria

| # | Given / When / Then | Test |
|---|---|---|
| B1 | Given a selected tool or Realm-workspace source bundle, when its intake linkage is validated, then archive, lockfile, every resolved Cargo source, vendor tree, source-replacement config, digest records, and dependency license report agree exactly. | To be implemented: source-bundle linkage fixture. |
| B2 | Given retained-only Debian and Fedora source kits and their actual package build paths with networking disabled and empty Cargo caches, when source-kit recursion, emitted package documentation, selected bundles, the complete Realm workspace build, and all package-relevant staged workspace tests run (excluding only non-packaged `realm-agent-sdd`), then no hidden workspace is accepted, the installed guide names only the retained-kit workflow, all Cargo invocations use `--frozen --offline --locked`, deterministic source/VCS metadata where applicable, and no recipe fetch path exists. | `packaging/tool-sources/test-native-source-kits.sh`; `packaging/tool-sources/test-native-builds.sh` (Realm-workspace portion; selected Yazi/Starship bundle integration remains follow-on work) |
| B3 | Given a native package install and direct or systemd-user Realm session launch, when executable and PATH ownership are inspected, then only `/usr/lib/realm/bin/*` owns the three Realm tools, Realm-launched applications resolve them, and neither user manager nor DBus activation receives the private PATH, including with `REALM_IMPORT_PATH=1`. | To be implemented: package/session ownership fixture. |
| B4 | Given a rendered Realm Yazi theme at `YAZI_CONFIG_HOME`, when the selected v25.4 runtime loads it, then a strict schema guard has rejected legacy fields and canonical fields are consumed; given a controlled Starship invocation, the rendered configuration has no diagnostics and renders a known Realm feature. | To be implemented: rendered-config runtime fixture. |
| B5 | Given a selected dependency closure, when license evidence is inspected, then every resolved dependency has a linked license/notice record. | To be implemented: dependency-license fixture. |
| B6 | Given an exact committed workspace revision with an unchanged retained lockfile, when its source authority needs rebinding, then read-only repository CI alone creates and validates the candidate archive/records and retains exactly those three files as an artifact without committing or pushing them; a mutable ref, changed lockfile, local packaging command, or unvalidated candidate is rejected. | CI rebind workflow projection and transformation fixtures; bundle-linkage validator in the rebind job. |

## Boundaries and follow-on work

This specification completes the design required for SPEC 0023 A2 only. It
does not claim A2 is implemented, does not establish target availability (A3),
and does not establish immutable generation update or rollback behavior (A4).
It also does not claim full user configuration integration: the actual generated
templates are in `configs/templates/`, while the configuration directories
described by ADR 0007 are not currently present. That integration gap requires
its own accepted specification before it becomes a supported capability.

No public package repository, binary distribution, signing service, mirror,
container registry, backend, or network service is introduced.
