# The MVP cut line

**MVP = one person can log into realm and use it as their only desktop for a
week without reaching for another DE.**

That is the whole test. Everything below is judged against it, and anything that
does not serve it waits — however good it would look in a screenshot.

---

## In

| # | Capability | Why it is in | Crate / component |
|---|---|---|---|
| 1 | Log in and get a session | Without this there is no desktop | session entry, systemd units |
| 2 | Tile windows: summon, banish, focus, swap, six orbits, triptych + mono | This *is* the window manager — literally, under river 0.4 | `realm-core` + `realm-session` |
| 3 | See state: bar with orbits, layout, mode, title, clock, cpu/mem/net/battery | A tiling WM without a bar is unusable for a week | `realm-bar` |
| 4 | Discover keys: which-key strip + `?` grimoire | Chords no one can remember are chords no one uses | `realm-bar` |
| 5 | Launch things | Terminal, browser, anything on `PATH` | fuzzel themed as hecate |
| 6 | A terminal that looks like realm | Where the week is actually spent | foot + generated ANSI theme |
| 7 | Files: charon | yazi + realm keymap and theme | `configs/yazi` |
| 8 | Monitor: horus | btop + generated theme | `configs/btop` |
| 9 | Shell: thoth | zsh + starship, `nav@caldera :: ~%` by default | `configs/zsh` |
| 10 | One coherent theme across GTK, Qt and TUIs | The difference between a DE and a pile of programs | `realm-theme` + `realm-ctl theme apply` |
| 11 | Portals work: FileChooser, ScreenCast, **Settings**, and **Inhibit routed to `none`** | Browsers and Electron apps are non-negotiable in a work week. Settings is what stops every GTK4 and Flatpak app rendering light; Inhibit must be `none` or the gtk backend claims success and the screen blanks mid-call | `configs/portal` + ADR 0011 |
| 12 | Install on NixOS, Ubuntu and Fedora with River 0.4-compatible, target-specific packaging; Fedora uses its official native candidate | The stated targets | `packaging/` |
| 13 | `realm ctl doctor` | Tells the user what is wrong before they file a bug | `realm-ctl` |

## Out — deliberately, for now

| Deferred | Stopgap in MVP | Lands in |
|---|---|---|
| `realm-compositor` (Smithay) | river 0.4 via `RiverBackend`, with realm as its window manager | M5 |
| `realm-hecate` native launcher | themed fuzzel | M4 |
| `realm-odin` agent harness | run the agent runner in a terminal | M4 |
| urania orrery pane | — (the one pure-ornament pane) | M4 |
| charon *portal* open dialog | the toolkit's own dialog, themed | M4 |
| Kvantum / Qt theming beyond `qt6ct` colours | qt6ct colour scheme only | M6 |
| Minimal-motion pass | none — v1 is motionless by design | M6 |
| Multi-monitor beyond "it doesn't break" | single output is the tested path | M6 |

---

## Milestones

| | Milestone | Ships | Done when |
|---|---|---|---|
| **M0** | Foundations | `realm-core`, CI, docs, ADRs, repo furniture | `cargo test` green in CI; architecture reviewed |
| **M1** | Theming pipeline | `realm-theme`, templates, `realm ctl theme apply/lint` | One palette edit publishes a coherent sealed generation selected by future GTK, terminal, yazi and btop launches |
| **M2** | Session and bar | `realm-session` + `RiverBackend`, and the five protocols realm must *serve* under river (`river-layer-shell-v1`, `river-xkb-bindings-v1`, `river-input-management-v1`, `river-xkb-config-v1`, `river-libinput-config-v1` — the last two are why a laptop has a working touchpad and a switchable keyboard layout), plus `realm-bar` | Bar reflects live orbit/focus/mode changes, and the reference triptych geometry is pixel-exact on river |
| **M3** | **Daily-drivable** | Session entry, portals, packaging, install docs | A fresh NixOS/Ubuntu/Fedora box logs into realm and passes `doctor` |
| **M4** | Native clients | `realm-hecate`, `realm-odin`, urania, charon portal | The stopgaps are retired |
| **M5** | realm compositor | `realm-compositor` on Smithay, `NativeBackend` | The ledger runs the screen directly |
| **M6** | Polish | Qt/Kvantum, multi-monitor, a11y, optional minimal motion | Frame budgets held on a 2015-era laptop |

**M3 is the MVP.** M0–M3 is the critical path; nothing in M4+ blocks it.

Security checks and security-hardening review are deferred until after the MVP.
They are tracked as post-MVP work and do not gate the M0–M3 critical path.

---

## Sequencing rules

1. **Contracts before implementations.** `realm-core` types land before the crate
   that consumes them, so two components are never invented in parallel.
2. **Stopgaps must be swappable.** Every stopgap (fuzzel, river, btop) sits
   behind a config or a trait, never a hardcoded call. The name `river` may not
   appear outside `crates/realm-session/src/backend/`, `packaging/` and `docs/`.
3. **Nothing merges without a test.** Layout maths gets unit tests; anything
   touching a live socket gets an integration test; anything touching a
   distro gets a CI job on that distro.
4. **The budget is a gate, not a goal.** A change that misses a frame budget in
   [ARCHITECTURE.md §4](ARCHITECTURE.md) is a regression, not a trade-off.
5. **Native package builds run in CI only.** Local development does not install
   distro packaging toolchains or treat their absence as a blocker; the
   matching distro CI job supplies authoritative package-build evidence.
