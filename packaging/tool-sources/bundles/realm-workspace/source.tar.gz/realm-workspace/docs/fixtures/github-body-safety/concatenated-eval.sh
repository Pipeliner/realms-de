e"val" "$publisher"
