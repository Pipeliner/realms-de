#!/bin/sh

set -eu

script_dir=$(CDPATH='' cd "$(dirname "$0")" && pwd)
repo_root=$(CDPATH='' cd "$script_dir/.." && pwd)
guard="$script_dir/check-readme-truth-snapshot.sh"

# RED is deliberate: create the production check only after this harness fails.
if [ ! -x "$guard" ]; then
    echo "FAIL: missing executable README truth snapshot check: $guard" >&2
    exit 1
fi

tmp_dir=$(mktemp -d "${TMPDIR:-/tmp}/realm-readme-truth-test.XXXXXX")
trap 'rm -rf "$tmp_dir"' EXIT HUP INT TERM

tests_run=0

make_fixture() {
    name=$1
    fixture_root="$tmp_dir/$name"
    mkdir -p "$fixture_root/.github/workflows" \
        "$fixture_root/docs/assets" \
        "$fixture_root/crates" \
        "$fixture_root/packaging/session" \
        "$fixture_root/packaging/systemd" \
        "$fixture_root/packaging/nix" \
        "$fixture_root/packaging/debian" \
        "$fixture_root/packaging/fedora" \
        "$fixture_root/configs/portal" \
        "$fixture_root/configs/templates" \
        "$fixture_root/crates/realm-theme/src" \
        "$fixture_root/crates/realm-ctl/src" \
        "$fixture_root/crates/realm-session/src/bin" \
        "$fixture_root/crates/realm-bar/src" \
        "$fixture_root/crates/realm-bar/tests"
    cp "$repo_root/README.md" "$fixture_root/README.md"
    cp "$repo_root/docs/ROADMAP.md" "$fixture_root/docs/ROADMAP.md"
    cp "$repo_root/.github/workflows/ci.yml" "$fixture_root/.github/workflows/ci.yml"
    cp "$repo_root/docs/assets/capture-provenance.json" "$fixture_root/docs/assets/capture-provenance.json"
    cp "$repo_root/docs/assets/capture-review.md" "$fixture_root/docs/assets/capture-review.md"
    cp "$repo_root/docs/assets/control-grimoire-state.json" "$fixture_root/docs/assets/control-grimoire-state.json"
    cp "$repo_root/docs/assets/control-tiled-state.json" "$fixture_root/docs/assets/control-tiled-state.json"
    cp "$repo_root/docs/assets/realm-grimoire.png" "$fixture_root/docs/assets/realm-grimoire.png"
    cp "$repo_root/docs/assets/realm-tiled-desktop.png" "$fixture_root/docs/assets/realm-tiled-desktop.png"
    : >"$fixture_root/flake.nix"
    : >"$fixture_root/packaging/session/realm.desktop"
    : >"$fixture_root/packaging/session/realm-session"
    : >"$fixture_root/packaging/systemd/realm-session.target"
    : >"$fixture_root/configs/portal/realm-portals.conf"
    : >"$fixture_root/crates/realm-theme/Cargo.toml"
    : >"$fixture_root/crates/realm-theme/src/lib.rs"
    printf '%s\n' '#[test]' >"$fixture_root/crates/realm-theme/src/theme.rs"
    printf '%s\n' '[[bin]]' 'name = "realmctl"' >"$fixture_root/crates/realm-ctl/Cargo.toml"
    printf '%s\n' 'enum ThemeCommand {}' >"$fixture_root/crates/realm-ctl/src/main.rs"
    : >"$fixture_root/crates/realm-session/Cargo.toml"
    : >"$fixture_root/crates/realm-session/src/lib.rs"
    : >"$fixture_root/crates/realm-session/src/runtime.rs"
    : >"$fixture_root/crates/realm-session/src/bin/realm-wm.rs"
    : >"$fixture_root/crates/realm-bar/Cargo.toml"
    : >"$fixture_root/crates/realm-bar/src/main.rs"
    : >"$fixture_root/crates/realm-bar/tests/render_contract.rs"
    printf '%s\n' 'pub trait WmBackend {}' >"$fixture_root/crates/realm-session/src/backend.rs"
    : >"$fixture_root/packaging/nix/nixos-module.nix"
    : >"$fixture_root/packaging/debian/control"
    : >"$fixture_root/packaging/fedora/realm.spec"
    : >"$fixture_root/palette.toml"
    mkdir -p "$fixture_root/design" "$fixture_root/.claude"
    printf '%s\n' "$fixture_root"
}

run_guard() {
    "$guard" --root "$1" 2>&1
}

expect_pass() {
    name=$1
    fixture_root=$2
    tests_run=$((tests_run + 1))

    if ! output=$(run_guard "$fixture_root"); then
        printf 'FAIL: %s unexpectedly failed\n%s\n' "$name" "$output" >&2
        exit 1
    fi
    printf 'ok %d - %s\n' "$tests_run" "$name"
}

expect_fail() {
    name=$1
    fixture_root=$2
    expected=$3
    tests_run=$((tests_run + 1))

    if output=$(run_guard "$fixture_root"); then
        printf 'FAIL: %s unexpectedly passed\n%s\n' "$name" "$output" >&2
        exit 1
    fi
    case "$output" in
        *"$expected"*) ;;
        *)
            printf 'FAIL: %s failed for the wrong reason\nexpected: %s\nactual: %s\n' \
                "$name" "$expected" "$output" >&2
            exit 1
            ;;
    esac
    printf 'ok %d - %s\n' "$tests_run" "$name"
}

fixture_root=$(make_fixture canonical)
expect_pass canonical-snapshot "$fixture_root"

fixture_root=$(make_fixture missing-bar-entrypoint)
rm "$fixture_root/crates/realm-bar/src/main.rs"
expect_fail missing-bar-entrypoint "$fixture_root" \
    'README truth snapshot artifact is missing: crates/realm-bar/src/main.rs'

fixture_root=$(make_fixture stale-bar-status)
sed 's/Implemented and verified in the installed NixOS QEMU VM/Implemented with contract tests; live compositor verification pending/' \
    "$fixture_root/README.md" >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail stale-bar-status "$fixture_root" \
    'README must name installed NixOS VM verification for realm-bar'

fixture_root=$(make_fixture missing-tiled-capture)
rm "$fixture_root/docs/assets/realm-tiled-desktop.png"
expect_fail missing-tiled-capture "$fixture_root" \
    'README truth snapshot artifact is missing: docs/assets/realm-tiled-desktop.png'

fixture_root=$(make_fixture changed-tiled-capture)
printf 'changed\n' >>"$fixture_root/docs/assets/realm-tiled-desktop.png"
expect_fail changed-tiled-capture "$fixture_root" \
    'README tiled capture SHA-256 differs from preserved provenance'

fixture_root=$(make_fixture rewritten-original-provenance)
sed 's/1920x1080/1280x800/' "$fixture_root/docs/assets/capture-provenance.json" \
    >"$fixture_root/docs/assets/capture-provenance.next"
mv "$fixture_root/docs/assets/capture-provenance.next" \
    "$fixture_root/docs/assets/capture-provenance.json"
expect_fail rewritten-original-provenance "$fixture_root" \
    'README original capture provenance must remain byte-for-byte preserved'

fixture_root=$(make_fixture requested-resolution-as-capture-size)
sed 's/1280×800/1920×1080/' "$fixture_root/README.md" >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail requested-resolution-as-capture-size "$fixture_root" \
    'README capture caption must report PNG-IHDR-derived 1280x800 dimensions'

fixture_root=$(make_fixture missing-capture-review-link)
sed 's@docs/assets/capture-review.md@docs/assets/missing-review.md@' \
    "$fixture_root/README.md" >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail missing-capture-review-link "$fixture_root" \
    'README capture caption must link the visual review correction'

fixture_root=$(make_fixture missing-blocker)
sed '/issues\/168/d' "$fixture_root/README.md" >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail missing-blocker "$fixture_root" 'missing needs-human snapshot issue #168'

fixture_root=$(make_fixture resolved-font-question)
sed '/## Repo map/i\\| [#34 — resolved font policy](https://github.com/Pipeliner/realms-de/issues/34) | must not return |' \
    "$fixture_root/README.md" >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail resolved-font-question "$fixture_root" 'closed issue #34 must not appear in the needs-human snapshot'

fixture_root=$(make_fixture changed-issue-title)
sed 's/Does the 𓂃 prompt sigil survive/Does the prompt sigil survive/' \
    "$fixture_root/README.md" >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail changed-issue-title "$fixture_root" 'needs-human snapshot title differs from GitHub'

fixture_root=$(make_fixture empty-blocker)
sed "s/The public \`theme lint\` and \`theme diff\` JSON contracts\./ /" \
    "$fixture_root/README.md" >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail empty-blocker "$fixture_root" 'needs-human snapshot blocker is empty'

fixture_root=$(make_fixture stale-session-claim)
sed 's/Tracked pre-alpha contract/Planned. Not started/' "$fixture_root/README.md" \
    >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail stale-session-claim "$fixture_root" 'README must not call tracked session assets planned/not started'

fixture_root=$(make_fixture stale-fedora-installroot-status)
sed 's/the exact Fedora RPM verified in an empty installroot/the Fedora RPM build retained but installation unverified/' \
    "$fixture_root/README.md" >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail stale-fedora-installroot-status "$fixture_root" \
    'README status must name the Fedora RPM installroot evidence'

fixture_root=$(make_fixture stale-ubuntu-installroot-status)
sed 's/exact Ubuntu Realm and private River packages clean-install together in an empty amd64 Noble root/Ubuntu package installation remains pending/' \
    "$fixture_root/README.md" >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail stale-ubuntu-installroot-status "$fixture_root" \
    'README status must name the Ubuntu package-pair installroot evidence'

fixture_root=$(make_fixture stale-portal-status)
sed 's/FileChooser cancel, Settings read, and nonempty ScreenCast buffer/functional portal verification remains pending/' \
    "$fixture_root/README.md" >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail stale-portal-status "$fixture_root" \
    'README status must name the bounded functional portal evidence'

fixture_root=$(make_fixture missing-ci-invocation)
sed '/\.\/docs\/test-readme-truth-snapshot\.sh/d' \
    "$fixture_root/.github/workflows/ci.yml" >"$fixture_root/ci.next.yml"
mv "$fixture_root/ci.next.yml" "$fixture_root/.github/workflows/ci.yml"
expect_fail missing-ci-invocation "$fixture_root" 'documentation CI must run the README truth snapshot fixtures'

fixture_root=$(make_fixture commented-ci-invocations)
sed 's@^[[:space:]]*\./docs/\(test-readme-truth-snapshot\|check-readme-truth-snapshot\)\.sh@          # \&@' \
    "$fixture_root/.github/workflows/ci.yml" >"$fixture_root/ci.next.yml"
mv "$fixture_root/ci.next.yml" "$fixture_root/.github/workflows/ci.yml"
expect_fail commented-ci-invocations "$fixture_root" \
    'documentation CI must run the README truth snapshot fixtures'

fixture_root=$(make_fixture relocated-first-screen-identity)
sed 's/keyboard-first, gapless-tiling, Rust-first Wayland desktop environment/moved identity/' \
    "$fixture_root/README.md" >"$fixture_root/README.next"
printf '%s\n' 'keyboard-first, gapless-tiling, Rust-first Wayland desktop environment' \
    >>"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail relocated-first-screen-identity "$fixture_root" \
    'README first screen must state the full project identity'

fixture_root=$(make_fixture nonexistent-map-path)
sed 's@│  └─ portal/@│  └─ absent-portal/@' "$fixture_root/README.md" \
    >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail nonexistent-map-path "$fixture_root" \
    'README repository map must name configs/portal/'

fixture_root=$(make_fixture stale-roadmap)
sed 's/NativeBackend/NiriBackend/' "$fixture_root/docs/ROADMAP.md" \
    >"$fixture_root/ROADMAP.next"
mv "$fixture_root/ROADMAP.next" "$fixture_root/docs/ROADMAP.md"
expect_fail stale-roadmap "$fixture_root" 'roadmap must not refer to NiriBackend'

fixture_root=$(make_fixture changed-roadmap-m0)
sed 's/| \*\*in progress\*\* |/| planned |/' "$fixture_root/docs/ROADMAP.md" \
    >"$fixture_root/ROADMAP.next"
mv "$fixture_root/ROADMAP.next" "$fixture_root/docs/ROADMAP.md"
expect_fail changed-roadmap-m0 "$fixture_root" 'roadmap must mark M0 in progress'

fixture_root=$(make_fixture changed-roadmap-m3)
sed 's/\*\*\[M3\](#m3--daily-drivable) is the MVP\.\*\*/M3 is planned./' \
    "$fixture_root/docs/ROADMAP.md" >"$fixture_root/ROADMAP.next"
mv "$fixture_root/ROADMAP.next" "$fixture_root/docs/ROADMAP.md"
expect_fail changed-roadmap-m3 "$fixture_root" 'roadmap must identify M3 as the MVP'

fixture_root=$(make_fixture relocated-readme-m3)
sed 's/\*\*M3 is the MVP\.\*\*/M3 is planned./' "$fixture_root/README.md" \
    >"$fixture_root/README.next"
printf '%s\n' '**M3 is the MVP.**' >>"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail relocated-readme-m3 "$fixture_root" 'README status must identify M3 as the MVP'

fixture_root=$(make_fixture changed-snapshot-timestamp)
sed 's/2026-08-30T06:18:36Z/2026-08-30T06:18:37Z/' "$fixture_root/README.md" \
    >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail changed-snapshot-timestamp "$fixture_root" 'README needs-human snapshot timestamp differs from the accepted snapshot'

fixture_root=$(make_fixture missing-wm-seam)
rm "$fixture_root/crates/realm-session/src/backend.rs"
expect_fail missing-wm-seam "$fixture_root" \
    'README truth snapshot artifact is missing: crates/realm-session/src/backend.rs'

fixture_root=$(make_fixture missing-realmctl)
rm "$fixture_root/crates/realm-ctl/src/main.rs"
expect_fail missing-realmctl "$fixture_root" \
    'README truth snapshot artifact is missing: crates/realm-ctl/src/main.rs'

fixture_root=$(make_fixture missing-wm-binary)
rm "$fixture_root/crates/realm-session/src/bin/realm-wm.rs"
expect_fail missing-wm-binary "$fixture_root" \
    'README truth snapshot artifact is missing: crates/realm-session/src/bin/realm-wm.rs'

fixture_root=$(make_fixture stale-wm-status)
sed 's/Daemon and real River adapter verified in the installed NixOS QEMU VM/Daemon and real River adapter implemented; live compositor verification pending/' \
    "$fixture_root/README.md" >"$fixture_root/README.next"
mv "$fixture_root/README.next" "$fixture_root/README.md"
expect_fail stale-wm-status "$fixture_root" \
    'README must name installed NixOS VM verification for realm-wm'

fixture_root=$(make_fixture missing-nix-module)
rm "$fixture_root/packaging/nix/nixos-module.nix"
expect_fail missing-nix-module "$fixture_root" 'README truth snapshot artifact is missing: packaging/nix/nixos-module.nix'

fixture_root=$(make_fixture missing-debian-definition)
rm "$fixture_root/packaging/debian/control"
expect_fail missing-debian-definition "$fixture_root" 'README truth snapshot artifact is missing: packaging/debian/control'

fixture_root=$(make_fixture missing-fedora-definition)
rm "$fixture_root/packaging/fedora/realm.spec"
expect_fail missing-fedora-definition "$fixture_root" 'README truth snapshot artifact is missing: packaging/fedora/realm.spec'

fixture_root=$(make_fixture missing-theme-tests)
rm "$fixture_root/crates/realm-theme/src/theme.rs"
expect_fail missing-theme-tests "$fixture_root" 'README truth snapshot artifact is missing: crates/realm-theme/src/theme.rs'

printf 'PASS: %d README truth snapshot fixtures\n' "$tests_run"
