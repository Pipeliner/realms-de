# ADR 0004 — Newline-delimited JSON over a unix socket

- **Status:** Accepted (2026-08-26; IPC security amendment accepted 2026-08-28;
  transport-liveness correction 2026-09-11)
- **Deciders:** realm maintainers
- **Supersedes / Superseded by:** —

## Context

ADR 0003 puts one daemon in charge of state. It needs a wire protocol with four
properties, in this order of importance:

1. **Scriptable by hand.** realm is a keyboard-first, power-user desktop. A user
   who wants to bind something we did not think of should be able to do it from
   a shell script, today, without a library. The hand-written stream contains a
   matching Hello followed by one request, with an LF after each JSON value:

   ```text
   {"cmd":"hello","arg":{"version":1,"client":"shell"}}
   {"cmd":"switch-orbit","arg":3}
   ```

   Sending those two frames to `$XDG_RUNTIME_DIR/realm/ctl.sock` with `socat`
   is the bar we are aiming at.
2. **Unmisreadable framing.** A half-written frame must never parse as a
   complete one. `docs/PITFALLS.md` lists version skew between components as a
   packaging pitfall; a protocol that silently misinterprets a truncated or
   older frame turns that into data corruption.
3. **Cheap.** The bar's redraw budget is 8 ms end to end. Serialisation must not
   be a meaningful fraction of that.
4. **Available before the desktop is.** The session starts, then everything
   else. The protocol must not depend on something the session itself has to
   start first.

## Decision

One newline-delimited JSON stream over a `SOCK_STREAM` unix socket.

### Endpoint and admission

- The only production endpoint is `$XDG_RUNTIME_DIR/realm/ctl.sock`.
  `XDG_RUNTIME_DIR` must be an absolute existing directory; if it is absent,
  relative, or not a directory, path resolution fails with
  `IpcPathError::MissingRuntimeDir` and neither a client nor the daemon falls
  back to `/tmp`. `realm-wm` exits non-zero before binding; `realmctl` reports the
  same condition as "not inside a realm session" and does not connect anywhere.
- `REALM_SOCKET` is not a production override and `realmctl --socket` is not a
  public option. The only test seam is a non-production path resolver which
  receives an explicit temporary runtime directory. It must produce the same
  `realm/ctl.sock` descendant and perform the same ownership/type checks as the
  production resolver; it must not accept an arbitrary socket pathname. This
  seam exists solely to make isolated integration fixtures possible without
  mutating process environment.
- The planned Linux-only `realm-control` workspace library owns the shared
  server/client endpoint capabilities and later transport. `realm-core::ipc`
  retains only portable wire values and codec/version work; `realm-ctl` does
  not depend on `realm-session`. Non-Linux `realm-control` builds fail
  explicitly.
- Endpoint identity, descriptor-relative resolution, ownership/mode policy,
  stale reclaim predicate, and the bind/activate capability transition are
  defined completely by SPEC 0007. Linux has no `bindat` or `connectat`, so the
  shared crate binds and connects through a private generated
  `/proc/self/fd/<realm-dir-fd>/ctl.sock` bridge after capability validation;
  inaccessible procfs fails closed with no display-path fallback.
- Before inspecting an existing socket, a server holds an exclusive
  nonblocking `flock` on a private, independent
  `O_DIRECTORY | O_CLOEXEC` description of the validated realm directory.
  `FD_CLOEXEC` is verified and the fd is never exposed, so an exec-launched
  client cannot inherit ownership. This protects the bound-but-not-listening
  recovery window, where connect refusal alone cannot distinguish a live owner
  from a stale socket. After bind, pathname ownership is proved from no-follow
  pathname metadata plus `getsockname` and `SO_ACCEPTCONN`, not by comparing
  the pathname inode with the distinct sockfs inode returned for the socket fd.
  Only verified `ECONNREFUSED` under the singleton lock authorizes a stale
  candidate; timeout, success, permission failure, overload, and every other
  result preserve the entry. Listening is a consuming one-shot operation after
  session recovery reaches `Live`, and readiness follows verified activation.
- Before reading any frame, the listener obtains Linux `SO_PEERCRED`. It admits
  only peers whose uid equals the daemon's effective uid. A missing credential,
  credential lookup failure, or different uid closes that connection without a
  protocol reply. Directory permissions are defence in depth, not a substitute
  for peer admission. The 64-slot cap bounds memory and per-turn work but does
  not promise admission while 64 trusted same-euid peers hold every slot.

### Connection protocol and liveness

- `Request::Hello { version, client }` is the mandatory first complete frame on
  **every** connection, including one-shot shell clients. The server answers
  `Response::Hello` before any other response. A matching version enters
  `SendingHello` and becomes Ready only after the complete Hello response
  drains; a mismatch receives the server version and is then closed. A request
  before `Hello`, a second `Hello`, or `Subscribe` before a successful matching
  Hello is refused with `Response::Error` and then closed. Shell scriptability
  remains: a script writes a Hello frame followed by its request, each newline
  terminated.
- A ready client may issue ordinary requests. `Subscribe` is a terminal request:
  after a successful Hello it changes the connection into a subscriber, emits
  an immediate `Event::State` snapshot, and accepts no further client frames.
  Positive subsequent input removes only that subscriber. A clean read-half EOF
  is allowed, so a shell may half-close after Hello plus one request and a
  subscriber may stop writing while continuing to receive events.
- The complete state machine, frame/error classification, capacity accounting,
  queue classes, nonblocking write deadlines, caller-chosen test instants, and
  test-only credential injection are defined by SPEC 0007. They are
  intentionally a state machine: NDJSON
  removes length-prefix state, not connection, handshake, queue, or deadline
  state. SPEC 0007 uses explicit `Instant` values rather than a production clock
  trait, consumes the active listener into a server with stable poll tokens,
  and limits one service quantum to one ready token and at most one socket-I/O
  syscall. These are bounded-work guarantees for the transport; SPEC 0003/#38,
  the real River backend in #40, and #65 own the combined-loop
  key-to-`manage_finish` guarantee.

- One JSON value per line. `ipc::encode` appends the newline and
  enforces SPEC 0007's total-frame limit while serializing;
  `ipc::tests::requests_round_trip_through_a_frame` asserts every frame contains
  exactly one newline.
- `Request`, `Response` and `Event` are adjacently-tagged serde enums
  (`tag = "cmd", content = "arg"` and so on), which keeps frames readable and
  keeps the tag stable when a variant gains fields.
- `PROTOCOL_VERSION` (currently 1) is exchanged by `Request::Hello` /
  `Response::Hello` before any operation. The session always answers Hello,
  including on mismatch, so the client can print a useful error. A mismatched
  client refuses to proceed rather than guessing at fields.
- Unknown frames are an error, never a panic
  (`ipc::tests::unknown_frames_are_an_error_not_a_panic`).

## Alternatives considered

| Option | Why it was attractive | Why it lost |
|---|---|---|
| **D-Bus** | The correct desktop citizenship answer, and it is not close. We already require a session bus for portals (ADR 0011), so it is running regardless. Free service activation, free signal broadcast to multiple subscribers, introspection, `busctl` and `gdbus` as ready-made debugging tools, and other desktop components could integrate with realm without us shipping a library | Scripting D-Bus is meaningfully worse than scripting a socket: `busctl call` needs a signature string and gets the marshalling wrong in ways that are hard to diagnose. It adds a dependency (`zbus`) to every client including the bar. And it inverts a startup ordering we would rather control: the session would need the bus healthy before it could serve, when in fact the session is what puts `WAYLAND_DISPLAY` *into* the bus environment. This was the closest call in this ADR, and D-Bus remains the right answer if realm ever needs third-party integrations |
| **A binary codec** (bincode, postcard, CBOR) | Smaller frames, faster encode/decode, self-delimiting length prefixes | Solves a problem we do not have. `RealmState` is a few hundred bytes and serialises in microseconds against an 8 ms budget. It costs the entire scriptability property, which is requirement 1 |
| **A Wayland protocol extension** | The most "correct" place for compositor state; no second socket; automatic lifetime tied to the display | Only reachable from a Wayland client, so `realmctl` from a TTY or an SSH session could not use it. Requires the compositor to serve it, which couples clients to the compositor and undoes ADR 0002 and ADR 0003. Extension design and codegen is real work for no user-visible gain |
| **HTTP on a unix socket** | Every language has a client; trivially introspectable with `curl` | Request/response only. Push subscription needs SSE or websockets bolted on, and we would have written a worse version of what NDJSON already does |

## Consequences

### Good

- `socat`, `nc -U`, `jq` and a shell are a complete client: write the mandatory
  Hello frame first. `realmctl` is a thin wrapper rather than a privileged path.
- Framing is unambiguous by inspection: if there is no newline yet, the frame is
  not complete. There is no length prefix to get wrong; the explicit connection
  state machine in SPEC 0007 governs handshake, queues, and deadlines.
- Serde does the work. Adding a `Request` variant is one enum arm and the tests
  cover it.
- The fixed per-user runtime endpoint plus same-uid credential admission avoids
  trusting a world-visible fallback directory or caller-controlled endpoint.
- Version skew fails loudly at Hello instead of quietly at field access.

### Bad

- JSON is not free. Every state push formats a frame, and SPEC 0007 enforces a
  65,536-byte total-frame ceiling with bounded encoding. An oversized one-peer
  response or initial state closes that peer; an oversized state publication
  closes the bounded current subscriber set and reports its stable ids in
  ascending order, without affecting non-subscribers.
- No service activation. Something must start the session before a client
  connects. `ClientEndpoint` makes one bounded attempt; `realmctl` owns the
  exact six-attempt startup schedule for the race. Its targets are absolute
  not-before offsets, so a slow attempt skips elapsed sleep rather than moving
  later targets or overlapping another attempt.
- We are not a D-Bus citizen, so a third-party panel or a desktop integration
  cannot talk to realm without implementing our protocol.
- A JSON value containing a literal newline inside a string is escaped by serde,
  so framing is safe — but only because we always encode through `ipc::encode`.
  A hand-rolled writer elsewhere could break it.

### Neutral

- One socket serves both request/response and subscription. A subscriber's
  connection simply stays open and receives `Event` frames interleaved with
  nothing else, because subscribers do not issue further requests.

## Reversal

Low. The wire format is confined to `realm-core::ipc`; Linux endpoint and
transport mechanics are confined to shared `realm-control`. Adding a D-Bus
surface *alongside* the socket, rather than instead of it, is the likely path
and would be additive: a D-Bus object that proxies the same `Request`/`Response`
types. Estimated a week for the proxy, no changes to existing clients.

The signal to reconsider is a concrete integration request from outside realm —
someone wanting to drive orbits from an existing panel or a global hotkey daemon
— or evidence that startup ordering would be simpler with bus activation.

## Guard

- `ipc::tests::requests_round_trip_through_a_frame` — asserts single-line
  framing and exact round-trip for a representative set of variants.
- `ipc::tests::responses_round_trip`.
- `ipc::tests::unknown_frames_are_an_error_not_a_panic` — an unrecognised
  command or malformed input must be a decode error.
- *Required before M2 implementation:* #218 owns SPEC 0007 endpoint/server
  evidence in A1–A9 and A11; the explicitly separated client half of A2 plus
  A10 and A13–A16 are #41; A12 is #38.
  These cover endpoint capability, singleton ownership, stale probing,
  activation/cleanup, the single-attempt client and retry driver, admission,
  state/half-close, stable tokens, frame bounds, arbitration, deadlines,
  shutdown, and subscriber coalescing.
- *Planned (M2):* a CI job that drives a live session end to end with `socat`
  and `jq` only, so the scriptability claim is tested rather than asserted.
- *Required before M2 implementation:* SPEC 0007 A17 is split: #41 owns the
  bounded-transport test, #38 owns combined-loop ordering, #40 supplies real
  River `manage_finish`, and #65 owns the real Linux key-to-`manage_finish`
  budget test with #38/#40.
