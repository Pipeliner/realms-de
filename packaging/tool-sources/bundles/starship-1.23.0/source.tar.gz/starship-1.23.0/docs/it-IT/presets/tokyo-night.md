[Return to Presets](./#pastel-powerline)

# Tokyo Night Preset

This preset is inspired by [tokyo-night-vscode-theme](https://github.com/enkia/tokyo-night-vscode-theme).

![Screenshot of Tokyo Night preset](/presets/img/tokyo-night.png)

### Prerequisiti

- Un [ Nerd Font ](https://www.nerdfonts.com/) installato e abilitato nel tuo terminale

### Configurazione

```sh
starship preset tokyo-night -o ~/.config/starship.toml
```

[Click to download TOML](/presets/toml/tokyo-night.toml){download}

<<< @/public/presets/toml/tokyo-night.toml
