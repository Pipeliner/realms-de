[Return to Presets](./#catppuccin-powerline)

# Catppuccin Powerline Preset

This preset is a minimally modified version of [Gruvbox Rainbow](./gruvbox-rainbow.md) using the [Catppuccin](https://github.com/catppuccin/catppuccin) theme palette.

![Screenshot of Catppuccin Powerline preset](/presets/img/catppuccin-powerline.png)

### 先決要求

- 已安裝 [Nerd Font](https://www.nerdfonts.com/)，並在終端機被啟用。

### 設定

```sh
starship preset catppuccin-powerline -o ~/.config/starship.toml
```

By default this preset uses the Mocha flavour of Catppucin, but you can specify any of the flavours by modifying the value of `palette`:

- `catppuccin_mocha`
- `catppuccin_frappe`
- `catppuccin_macchiato`
- `catppuccin_latte`

[點擊此處下載 TOML](/presets/toml/catppuccin-powerline.toml)

<<< @/public/presets/toml/catppuccin-powerline.toml
