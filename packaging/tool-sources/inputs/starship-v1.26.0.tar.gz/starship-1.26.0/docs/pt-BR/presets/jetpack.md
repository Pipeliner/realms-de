[Retornar para Personalizações](./#jetpack)

# Jetpack Preset

This is a pseudo minimalist preset inspired by the [geometry](https://github.com/geometry-zsh/geometry) and [spaceship](https://github.com/spaceship-prompt/spaceship-prompt) prompts.

> Jetpack uses the terminal's color theme.

![Captura de tela do Jetpack preset](/presets/img/jetpack.png)

### Prerequisite

- Requires a shell with [`right-prompt`](https://starship.rs/advanced-config/#enable-right-prompt) support.
- [Jetbrains Mono](https://www.jetbrains.com/lp/mono/) is recommended.

### Configuração

```sh
starship preset jetpack -o ~/.config/starship.toml
```

[Click to download TOML](/presets/toml/jetpack.toml){download}

<<< @/public/presets/toml/jetpack.toml
