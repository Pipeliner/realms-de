[Retornar para Personalizações](./#tokyo-night)

# Predifinição Tokyo Night

Esta predefinição é inspirado por [tokyo-night-vscode-theme](https://github.com/enkia/tokyo-night-vscode-theme).

![Captura de tala da predefinissão Tokyo Night preset](/presets/img/tokyo-night.png)

### Pré-requisitos

- Uma fonte [Nerd Font](https://www.nerdfonts.com/) instalada e ativada em seu terminal

### Configuração

```sh
starship preset tokyo-night -o ~/.config/starship.toml
```

[Click to download TOML](/presets/toml/tokyo-night.toml){download}

<<< @/public/presets/toml/tokyo-night.toml
