[Return to Presets](./#pure-prompt)

# Pure Preset

This preset emulates the look and behavior of [Pure](https://github.com/sindresorhus/pure).

![Screenshot of Pure preset](/presets/img/pure-preset.png)

### Cấu hình

```sh
starship preset pure-preset -o ~/.config/starship.toml
```

[Click to download TOML](/presets/toml/pure-preset.toml){download}

<<< @/public/presets/toml/pure-preset.toml
