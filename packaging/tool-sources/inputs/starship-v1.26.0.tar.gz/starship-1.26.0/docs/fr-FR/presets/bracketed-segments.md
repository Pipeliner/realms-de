[Retourner aux préréglages](./#bracketed-segments)

# Préréglage Segments entre crochets

Ce préréglage modifie le format de tous les modules intégrés pour afficher leur segment entre crochets au lieu d'utiliser les labels par défaut de Starship ("via", "on", etc.).

![Capture d'écran du préréglages Segments entre crochets](/presets/img/bracketed-segments.png)

### Configuration

```sh
starship preset bracketed-segments -o ~/.config/starship.toml
```

[Cliquez pour télécharger TOML](/presets/toml/bracketed-segments.toml){download}

<<< @/public/presets/toml/bracketed-segments.toml
