[Retourner aux préréglages](./#no-runtime-versions)

# Préréglage Pas de version des environnements

Ce préréglage masque la version des environnements. Si vous travaillez dans des conteneurs ou environnements virtuels, celui-là est pour vous!

![Capture d'écran du préréglage Pas de version des environnements](/presets/img/no-runtime-versions.png)

### Configuration

```sh
starship preset no-runtime-versions -o ~/.config/starship.toml
```

[Cliquez pour télécharger TOML](/presets/toml/no-runtime-versions.toml){download}

<<< @/public/presets/toml/no-runtime-versions.toml
