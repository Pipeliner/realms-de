[Return to Presets](./#tokyo-night)

# Tokyo Night Preset

This preset is inspired by [tokyo-night-vscode-theme](https://github.com/enkia/tokyo-night-vscode-theme).

![Screenshot of Tokyo Night preset](/presets/img/tokyo-night.png)

### المتطلبات الأساسية

- تثبيت [Nerd Font](https://www.nerdfonts.com/) وتمكينه في موجه الأوامر الخاصة بك

### Configuration

```sh
starship preset tokyo-night -o ~/.config/starship.toml
```

[Click to download TOML](/presets/toml/tokyo-night.toml){download}

<<< @/public/presets/toml/tokyo-night.toml
