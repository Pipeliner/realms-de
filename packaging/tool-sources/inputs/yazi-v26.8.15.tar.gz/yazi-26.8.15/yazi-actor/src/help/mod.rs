yazi_macro::mod_flat!(arrow close escape toggle);
