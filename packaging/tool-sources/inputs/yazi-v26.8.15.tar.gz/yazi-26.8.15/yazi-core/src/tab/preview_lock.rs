use mlua::Table;
use yazi_binding::elements::Rect;
use yazi_fs::file::FileRef;
use yazi_macro::impl_data_any;
use yazi_shared::{id::Id, url::UrlBuf};
use yazi_widgets::Renderable;

#[derive(Clone, Debug, Default)]
pub struct PreviewLock {
	pub url: UrlBuf,
	pub sig: Id,

	pub skip: usize,
	pub area: Rect,
	pub data: Vec<Renderable>,
}

impl_data_any!(PreviewLock);

impl TryFrom<Table> for PreviewLock {
	type Error = mlua::Error;

	fn try_from(t: Table) -> Result<Self, Self::Error> {
		let file: FileRef = t.raw_get("file")?;
		file.borrow(|f| {
			Ok(Self {
				url: f.url_owned(),
				sig: t.raw_get("sig")?,

				skip: t.raw_get("skip")?,
				area: t.raw_get("area")?,
				data: Default::default(),
			})
		})
	}
}
